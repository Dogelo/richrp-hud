window.addEventListener("message", function (event) {
    switch (event.data.action) {
      case "hud":
        Progress(event.data.health, ".health");
        Progress(event.data.armor, ".armor");
        Progress(event.data.breath, ".breath");
        if (event.data.IsRadarHidden) {
          document.getElementById("main").style.animation = "animacjamapa2 0.6s both";
        } else {
          document.getElementById("main").style.animation = "animacjamapa 0.6s both";
        }
        if(event.data.health < 25)
        {
          document.getElementById("health_").style.animation = "hud_anim 1s infinite"
        }else{
          document.getElementById("health_").style.animation = "none"
        }
        if(event.data.breath < 25)
        {
          document.getElementById("breath").style.animation = "hud_anim 1s infinite"
        }else{
          document.getElementById("breath").style.animation = "none"
        }
        break;
      case "updateStatus":
        updateStatus(event.data.status);
        break;
      case "maybe":
        document.getElementById("main").style.display = "flex";

        //ladowanie zapisu
        setTimeout(() => {
          loads();
        }, 1000);
  
        break;
      case "showui":
        $("body").fadeIn();
        break;
      case "hideui":
        $("body").fadeOut();
        break;
      case "voice-color":
        if (event.data.isTalking) {
          document.getElementById("glnzjeb").style.stroke = "#32fc00";
        } else {
          var color = document.querySelector("#siema12").value;
          var div = document.getElementById("glnzjeb")
          div.style.stroke = color
        }
        break;
      case "voice":
        if (event.data.prox == 3) {
          Progress(100, ".voice");
        } else if (event.data.prox == 2) {
          Progress(50, ".voice");
        } else if (event.data.prox == 1) {
          Progress(25, ".voice");
        }
        break;
      case "car":
        if (event.data.showhud) {
          $(".hudCar").fadeIn();
          setProgressSpeed(event.data.speed, ".progress-speed", event.data.maxSpeed);
          document.querySelector("#gearnumber").innerHTML = event.data.gear;
        } else {
          $(".hudCar").fadeOut();
        }
        break;
      case "seatbelt":
        $(".car-seatbelt-info img").attr("src", "img/seatbelt.png");
        if (event.data.seatbelt) {
          $(".car-seatbelt-info img").fadeOut();
        } else {
          $(".car-seatbelt-info img").fadeIn();
        }
        break;
      case "show_hud":
        document.querySelector("#hud_edit").style.display = "block"
        break;
    }
});

$(function (){
  $("#close").click(function () {
    $.post('https://fastside_newhud/NUIFocusOff', JSON.stringify({}));
    document.getElementById("hud_edit").style.display = "none"
  })
});

document.onkeyup = function (data) {
  if (data.which == 27 ) {
    $.post('https://fastside_newhud/NUIFocusOff', JSON.stringify({}));
    document.getElementById("hud_edit").style.display = "none"
  }
};

function Progress(percent, element) {
  var circle = document.querySelector(element);
  var radius = circle.r.baseVal.value;
  var circumference = radius * 2 * Math.PI;
  var html = $(element).parent().parent().find("span");

  circle.style.strokeDasharray = `${circumference} ${circumference}`;
  circle.style.strokeDashoffset = `${circumference}`;

  const offset = circumference - ((-percent * 100) / 100 / 100) * circumference;
  circle.style.strokeDashoffset = -offset;

  html.text(Math.round(percent));
}

function setProgressSpeed(value, element, maxSpeed) {
  var circle = document.querySelector(element);
  var radius = circle.r.baseVal.value;
  var circumference = radius * 2 * Math.PI;
  var html = $(element).parent().parent().find("span");
  var percent = (value * 100) / 220;

  circle.style.strokeDasharray = `${circumference} ${circumference}`;
  circle.style.strokeDashoffset = `${circumference}`;

  const offset = circumference - ((-percent * 73) / 100 / maxSpeed) * circumference;
  circle.style.strokeDashoffset = -offset;

  html.text(value);
}

function updateStatus(status){
  var hunger = status[0]
  var thirst = status[1]
  Progress(thirst.percent, ".thirst");
  Progress(hunger.percent, ".hunger");
}