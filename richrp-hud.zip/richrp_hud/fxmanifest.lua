fx_version 'bodacious'
game 'gta5'
version '1.0.1'

ui_page 'html/ui.html'

client_scripts {
	'client.lua'
}

files {
	'html/ui.html',
	'html/style.css',
	'html/main.js',
	'html/img/*.png',
	'html/img_edit/*.png',
}
