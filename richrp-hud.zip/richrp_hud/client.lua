

ESX = nil
local cam = false
local clearscreen = false
local UI = { 
	x =  0.000,
	y = -0.001
}
local showUi = true

-- ESX
Citizen.CreateThread(function()
	while ESX == nil do
		TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
		Citizen.Wait(0)
	end
end)


AddEventHandler('richrp_hud:changehud', function(status)
	if status then
		SendNUIMessage({action = 'hideui'})
		TriggerEvent('carhud:display', false)
	else
		SendNUIMessage({action = 'showui'})
		TriggerEvent('carhud:display', true)
	end
end)

RegisterCommand("cam", function(source, args, raw)
    cam = not cam
    if cam then
        ESX.UI.HUD.SetDisplay(0.0)
		SendNUIMessage({action = 'hideui'})
        TriggerEvent('chat:display', false)
        TriggerEvent('radar:setHidden', true)
        TriggerEvent('carhud:display', false)
    elseif not cam then
        ESX.UI.HUD.SetDisplay(1.0)
		SendNUIMessage({action = 'showui'})
        TriggerEvent('chat:display', true)
        TriggerEvent('radar:setHidden', false)
        TriggerEvent('carhud:display', true)
    end
end)

RegisterCommand("clearscreen", function(source, args, raw)
    clearscreen = not clearscreen
    if clearscreen then
        ESX.UI.HUD.SetDisplay(0.0)
		SendNUIMessage({action = 'hideui'})
        TriggerEvent('chat:display', false)
        TriggerEvent('radar:setHidden', true)
        TriggerEvent('carhud:display', false)
		TriggerEvent("esx_customui:toggle", false)
    elseif not clearscreen and LocalPlayer.state.oldhud then
		ESX.UI.HUD.SetDisplay(1.0)
        TriggerEvent('chat:display', true)
        TriggerEvent('radar:setHidden', false)
        TriggerEvent('carhud:display', true)
		TriggerEvent("esx_customui:toggle", true)
	elseif not clearscreen and not LocalPlayer.state.oldhud then
		ESX.UI.HUD.SetDisplay(1.0)
		SendNUIMessage({action = 'showui'})
        TriggerEvent('chat:display', true)
        TriggerEvent('radar:setHidden', false)
        TriggerEvent('carhud:display', true)
		TriggerEvent("esx_customui:toggle", false)
    end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(0)
		if cam then
			DisplayRadar(false)
			HideHudComponentThisFrame(5)
			HideHelpTextThisFrame()
			HideHudAndRadarThisFrame()
			drawRct(UI.x + 0.0, UI.y + 0.0, 1.0,0.075,0,0,0,255)
			drawRct(UI.x + 0.0, UI.y + 0.93, 1.0,0.08,0,0,0,255)
		else
			Citizen.Wait(1050)
		end
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(200)
		local ped = PlayerPedId()
		local pid = PlayerId()
		local health = (GetEntityHealth(ped) - 100)
		local armor = GetPedArmour(ped)
		local breath = GetPlayerUnderwaterTimeRemaining(pid) * 10
		local radarhidden = IsRadarHidden()

		if breath <= 0 then breath = 0 end

		if health <= 0 then health = 0 end

		if LocalPlayer.state.dead then health = 0 end

		if not IsPedSwimming(ped) and not IsPedSwimmingUnderWater(ped) then
			breath = GetPlayerSprintTimeRemaining(pid) * 10
		end
	
		SendNUIMessage({action = "hud", health = health, armor = armor, breath = breath, IsRadarHidden = radarhidden})
	end
end)

Citizen.CreateThread(function()
	while true do
		Citizen.Wait(105)
		local ped = PlayerPedId()
		if IsPedInAnyVehicle(ped, false) then
			local inCar = GetVehiclePedIsIn(ped, false)
			local maxSpeed = GetVehicleHandlingFloat(inCar, "CHandlingData", "fInitialDriveMaxFlatVel") * 1.2
			local vehicleSpeed = math.ceil(GetEntitySpeed(inCar) * 3.605936)
			local vehicleGear = GetVehicleCurrentGear(inCar)
                
			if (vehicleSpeed == 0 and vehicleGear == 0) or (vehicleSpeed == 0 and vehicleGear == 1) then
				vehicleGear = 'N'
			elseif vehicleSpeed > 0 and vehicleGear == 0 then
				vehicleGear = 'R'
			end
		
			local sendSpeed = 0
			if maxSpeed < 200 then
				sendSpeed = 115
			elseif maxSpeed < 300 then
				sendSpeed = 160
			elseif maxSpeed < 400 then
				sendSpeed = 250
			elseif maxSpeed < 500 then
				sendSpeed = 300
			elseif maxSpeed < 600 then
				sendSpeed = 325
			end
			SendNUIMessage({
				action = 'car',
				showhud = true,
				speed = vehicleSpeed,
				maxSpeed = sendSpeed,
				gear = vehicleGear
			})
			local beltStatus = exports['carblackout']:beltStatus()
			SendNUIMessage({
				action = "seatbelt",
				seatbelt = beltStatus,
			})
		else
			SendNUIMessage({
				action = 'car',
				showhud = false,
			})
			Citizen.Wait(500)
		end
	end
end)

function drawRct(x,y,width,height,r,g,b,a)
	DrawRect(x + width/2, y + height/2, width, height, r, g, b, a)
end

RegisterNetEvent('esx_customui:talking')
AddEventHandler('esx_customui:talking', function(prox)
	SendNUIMessage({action = "voice", prox = prox})
end)

RegisterNetEvent('esx_customui:istalking')
AddEventHandler('esx_customui:istalking', function(istalkingrly)
	if istalkingrly then
		SendNUIMessage({action = "voice-color", isTalking = true})
	else
		SendNUIMessage({action = "voice-color", isTalking = false})
	end
end)

RegisterNetEvent('esx_customui:updateStatus')
AddEventHandler('esx_customui:updateStatus', function(status)
	SendNUIMessage({action = "updateStatus", status = status})
end)

RegisterNetEvent('esx_hud:yes')
AddEventHandler('esx_hud:yes', function()
	SendNUIMessage({action = 'maybe'})
end)

RegisterCommand("hud", function(source, args, raw)
	showUi = not showUi
	if showUi then
		SendNUIMessage({
			action = 'showui'
		})
	else
		SendNUIMessage({
			action = 'hideui'
		})
	end
end, false)

RegisterKeyMapping('hud', 'Pokaż/ukryj HUD', 'keyboard', '')

RegisterCommand("hudedit", function(source, args, raw)
	SendNUIMessage({
		action = 'show_hud'
	})
	SetNuiFocus(true, true)
end)

RegisterNUICallback("NUIFocusOff", function()
	SetNuiFocus(false, false)
end)
