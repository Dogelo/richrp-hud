

ESX = nil 

TriggerEvent("esx:getSharedObject", function(obj)
	ESX = obj 
end)


RegisterServerEvent("jebacglnowskaszmakte:jebac")
AddEventHandler("jebacglnowskaszmakte:jebac", function()
	local sors = source 

	TriggerClientEvent("esx_hud:yes", sors) 
end)