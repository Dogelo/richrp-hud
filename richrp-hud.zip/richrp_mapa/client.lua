

local posX = 0.01
local posY = 0.0

local width = 0.183
local height = 0.32

local oldhud = false

buildradar = function()
  RequestStreamedTextureDict("RichRP", false)
  while not HasStreamedTextureDictLoaded("RichRP") do
    Citizen.Wait(100)
  end

	AddReplaceTexture("platform:/textures/graphics", "radarmasksm", "RichRP", "radarmasksm")

	SetMinimapClipType(1)
	SetMinimapComponentPosition('minimap', 'L', 'B', posX, posY, width, height)
	SetMinimapComponentPosition('minimap_mask', 'L', 'B', posX, posY, width, height)
	SetMinimapComponentPosition('minimap_blur', 'L', 'B', 0.012, 0.022, 0.256, 0.337)

  SetRadarBigmapEnabled(true, false)
  Citizen.Wait(0)
  SetRadarBigmapEnabled(false, false)
end

RegisterNetEvent('richrp_map:buildmap')
AddEventHandler('richrp_map:buildmap', function()
  Citizen.CreateThread(buildradar)
end)

local HUD = {
  Blip = nil,
}

Citizen.CreateThread(function()
  SetMapZoomDataLevel(0, 0.96, 0.9, 0.08, 0.0, 0.0)
  SetMapZoomDataLevel(1, 1.6, 0.9, 0.08, 0.0, 0.0)
  SetMapZoomDataLevel(2, 8.6, 0.9, 0.08, 0.0, 0.0)
  SetMapZoomDataLevel(3, 12.3, 0.9, 0.08, 0.0, 0.0)
  SetMapZoomDataLevel(4, 22.3, 0.9, 0.08, 0.0, 0.0)

  SetBlipAlpha(GetMainPlayerBlipId(), 0)
	SetBlipAlpha(GetNorthRadarBlip(), 0)
  while true do
    Citizen.Wait(500)
    local ped = PlayerPedId()
    local heading = GetEntityHeading(ped)
    local vehicle = IsPedInAnyVehicle(ped, false)
    if HUD.Blip and DoesBlipExist(HUD.Blip) then
      RemoveBlip(HUD.Blip)
    end

    HUD.Blip = AddBlipForEntity(ped)
    SetBlipSprite(HUD.Blip, (vehicle and 545 or 1))

    SetBlipScale(HUD.Blip, 1.0)
    SetBlipCategory(HUD.Blip, 1)
    SetBlipPriority(HUD.Blip, 10)
    SetBlipColour(HUD.Blip, 55)
    SetBlipAsShortRange(HUD.Blip, true)

    SetBlipRotation(HUD.Blip, math.ceil(heading))
    ShowHeadingIndicatorOnBlip(HUD.Blip, true)

    BeginTextCommandSetBlipName("STRING")
    AddTextComponentString("Twoja pozycja")
    EndTextCommandSetBlipName(HUD.Blip)
  end
end)

RegisterCommand("oldhud", function(source, args, raw)
  oldhud = not oldhud
  if oldhud then
    TriggerServerEvent('richrp_hud:changehudstatus', true)
    TriggerEvent('richrp_hud:changehud', true)
    LocalPlayer.state:set('oldhud', true, true)
    Citizen.CreateThread(function()
      RemoveReplaceTexture("platform:/textures/graphics", "radarmasksm")
      SetMinimapClipType(0)
      SetMinimapComponentPosition("minimap", "L", "B", -0.0045, 0.002, 0.150, 0.188888)
      SetMinimapComponentPosition("minimap_mask", "L", "B", 0.020, 0.032, 0.111, 0.159)
      SetMinimapComponentPosition("minimap_blur", "L", "B", -0.03, 0.022, 0.266, 0.237)
      SetRadarBigmapEnabled(true, false)
      Citizen.Wait(0)
      SetRadarBigmapEnabled(false, false)
    end)
  elseif not oldhud then
    LocalPlayer.state:set('oldhud', false, true)
    TriggerServerEvent('richrp_hud:changehudstatus', false)
    TriggerEvent('richrp_hud:changehud', false)
    TriggerEvent('richrp_map:buildmap')
  end
end)

RegisterNetEvent('richrp_map:requesthud')
AddEventHandler('richrp_map:requesthud', function(status)
  oldhud = status
  if status then
    TriggerEvent('richrp_hud:changehud', true)
    LocalPlayer.state:set('oldhud', true, true)
    Citizen.CreateThread(function()
      RemoveReplaceTexture("platform:/textures/graphics", "radarmasksm")
      SetMinimapClipType(0)
      SetMinimapComponentPosition("minimap", "L", "B", -0.0045, 0.002, 0.150, 0.188888)
      SetMinimapComponentPosition("minimap_mask", "L", "B", 0.020, 0.032, 0.111, 0.159)
      SetMinimapComponentPosition("minimap_blur", "L", "B", -0.03, 0.022, 0.266, 0.237)
      SetRadarBigmapEnabled(true, false)
      Citizen.Wait(0)
      SetRadarBigmapEnabled(false, false)
    end)
  else
    LocalPlayer.state:set('oldhud', false, true)
    TriggerEvent('richrp_hud:changehud', false)
    TriggerEvent('richrp_map:buildmap')
    TriggerEvent('esx_hud:yes')
  end
end)

Citizen.CreateThread(function()
  local minimap = RequestScaleformMovie("minimap")
  while true do
    Citizen.Wait(0)
    SetRadarZoom(1200)
    if not oldhud then
      BeginScaleformMovieMethod(minimap, "SETUP_HEALTH_ARMOUR")
      ScaleformMovieMethodAddParamInt(3)
      EndScaleformMovieMethod()
    end
  end
end)