
ESX  = nil 

TriggerEvent('esx:getSharedObject', function(obj)
  ESX = obj 
end)


RegisterServerEvent('richrp_hud:changehudstatus')
AddEventHandler('richrp_hud:changehudstatus', function(kurwa)
  local xPlayer = ESX.GetPlayerFromId(source)
  local _source = source 

  if kurwa == true then 
    TriggerClientEvent('richrp_map:requesthud', source, true)
  elseif kurwa == false then 
    TriggerClientEvent('richrp_map:requesthud', source, false)
  end
end)

